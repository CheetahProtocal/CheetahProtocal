import React from 'react';
import { Routes } from './routes';
// import { Routes } from './views/preLaunch/routes'

function App() {
  return <Routes />;
}

export default App;
