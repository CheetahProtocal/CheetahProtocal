export interface SelectCardProps {
  title: string;
  subtitle: string;
  isSelected: boolean;
  onClick?: () => void;
}
